#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include "Dice.h"
#include "Player.h"

using namespace std;

int main()
{  
      // creating Player p1 with 5 dices
      Player p1(5);
      srand(time(NULL));
      p1.playerRoll();
      
      for (int i = 0; i < 5; i++){
            cout << p1.getDiceValueAtIndex(i) << " ";
      }
      cout << endl;
      return 0;
}
//complie whole thing
//g++ -std=c++11 -o yahtzee Dice.cpp Player.cpp Yahtzee.cppcompl

//compile dice driver
// g++ -std=c++11 -o dice Dice.cpp DiceDriver.cpp

// to run:
// ./yahrzee
// ./dice