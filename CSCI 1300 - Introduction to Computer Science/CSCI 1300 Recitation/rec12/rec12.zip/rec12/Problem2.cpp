#include <iostream>
#include <algorithm>
#include <string>

using namespace std;


string decimalToBinaryRecursive(int decimal)
{
    int remain;
    int result;
    string binary = "";
    string oneMoreTime;
    string totalResult;
    
    if (decimal <= 1)
    {
        binary = binary + to_string(decimal);
        reverse(totalResult.begin(), totalResult.end());
        return binary;
    }
    else
    {
        remain = decimal%2;
        result = decimal/2;
        binary = binary + to_string(remain);
        oneMoreTime = decimalToBinaryRecursive(result);
        
        return (oneMoreTime + binary);
    }
    
    
}