#include <iostream>
#include <string>
#include <algorithm>

using namespace std;

string decimalToBinaryIterative(int decimal)
{
    string result;
    string binary = "";
    if (decimal <= 1)
    {
        binary = to_string(decimal);
        return binary;
    }
    while (decimal > 0)
    {
        result = to_string(decimal%2);
        binary = binary + result;
        decimal = decimal/2;
    }
    
    reverse(binary.begin(),binary.end());
    return binary;
}