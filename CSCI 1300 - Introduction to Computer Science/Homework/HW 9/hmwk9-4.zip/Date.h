#include <iostream>

#ifndef DATE_H
#define DATE_H

class Date
{
    int year;
    int month;
    int day;
    int numDaysInEachMonth[12] = {31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    
    public:
    
    Date();
    
    void setMonth(int);
    void setDay(int);
    void getCurrentDate();
    
    void restDays(int);
    void restHunting();
    
    
    
};


#endif
