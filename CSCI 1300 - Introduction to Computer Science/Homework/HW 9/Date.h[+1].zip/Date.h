#include <iostream>

#ifndef DATE_H
#define DATE_H

class Date
{
    int year;
    int month;
    int day;
    int currentDate[][31];
    
    public:
    
    Date();
    Date(int, int, int);
    
    void setYear(int);
    void setMonth(int);
    void setDay(int);
    void showDate();
    
};


#endif
