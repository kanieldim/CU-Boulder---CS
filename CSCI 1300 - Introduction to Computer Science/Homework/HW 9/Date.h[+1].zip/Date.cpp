#include <iostream>
#include "Date.h"


using namespace std;


Date::Date()
{
    year = 1847;
    month = 3;
    day = 28;
}

Date::Date(int monthA, int dayA)
{
    month = monthA;
    day = dayA;
}


void Date::setDay(int dayA)
{
    if (month == 3 || month == 5)
    {
        if (dayA >= 1 && dayA <= 31)
        {
            day = dayA;
        }
        else
        {
            cout << "Invalid Day" << endl;
        }
    }
    if (month == 4)
    {
        if (dayA >= 1 && dayA <= 30)
        {
            day = dayA;
        }
        else
        {
            cout << "Invalid Day" << endl;
        }
    }  
}

void Date::setMonth(int monthA)
{
	if (monthA >= 3 && monthA <= 5)
	{
	    month = monthA;
	}
	else
	{
	    cout << "Invalid month" << endl;
	}
}
