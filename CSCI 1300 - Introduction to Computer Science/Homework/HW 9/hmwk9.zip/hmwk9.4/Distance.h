#include <iostream>

#ifndef DISTANCE_H
#define DISTANCE_H

using namespace std;

class Distance
{
    mileStones[6];
    riverStones[4];
    int riverDepth;
    int nextDestination;
    int randomTravel;
    
    
    public:
        Distance();
        
        void readMileStones(string); 
        
        
        int continueTrail();
        
        int readBooks(string);
        int readRatings(string);
        void printAllBooks();
        int getCountReadBooks(string);
        double calcAvgRating(string);
        bool addUser(string);
        bool checkOutBook(string, string, int);
        void viewRatings(string);
        void getRecommendations(string);
};

#endif