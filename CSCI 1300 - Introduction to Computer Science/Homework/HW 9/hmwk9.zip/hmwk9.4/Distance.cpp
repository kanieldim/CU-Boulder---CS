


void Distance::readMileStones(string nameFile) 
{
    string line = "";
    ifstream inFile;
    inFile.open(nameFile);
    
    while (getline(inFile, line))
    {
        line = 
    }
}


int columns = 0; // set up variables
    string line = "";
    string authorTitle[2];
    string title;
    string author;
    
    ifstream inFile; // set up file name
    inFile.open(nameFile); // open file
    
    if( !inFile.is_open() ) // if file does not open, return -1
    {
        return -1;
    }
    
    while ( getline(inFile, line) && numBooks < 200) // while every line in the file
    {
        columns = split ( line, ',', authorTitle, 2 ); // spliting the line to author and title by using comma delimiter
        author = authorTitle[0]; // storing an author to the array, authors
        title = authorTitle[1];  // storing a title to the array, titles
        
        books[numBooks].setTitle ( title ); // storing title of the book into books array at index (numBooks)
        books[numBooks].setAuthor ( author ); // storing author of the book into books array at index (numBooks)
        numBooks++; // add 1 to numbooks
    }
    inFile.close(); // close file
    
    return numBooks; // return numBooks
}