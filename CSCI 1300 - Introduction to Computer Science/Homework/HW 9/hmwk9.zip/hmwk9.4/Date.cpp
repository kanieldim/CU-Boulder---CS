#include "Date.h"

using namespace std;


Date::Date()
{
    year = 1847;
    month = 3;
    day = 28;
    numDaysInEachMonth[12]; // = {31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    // currentDate[];
}

void Date::setDay(int dayA)
{
    if (month == 3 || month == 5)
    {
        if (dayA >= 1 && dayA <= 31)
        {
            day = dayA;
        }
        else
        {
            cout << "Invalid Day" << endl;
        }
    }
    if (month == 4)
    {
        if (dayA >= 1 && dayA <= 30)
        {
            day = dayA;
        }
        else
        {
            cout << "Invalid Day" << endl;
        }
    }  
}

void Date::setMonth(int monthA)
{
	if (monthA >= 3 && monthA <= 5)
	{
	    month = monthA;
	}
	
}

void Date::getCurrentDate()
{
    cout << " - The current date: " << month << " - " << day << " - " << year << endl;
}

void Date::restDays(int numOfDays)
{
    if(day + numOfDays > numDaysInEachMonth[month])
    {
        day = day + numOfDays - numDaysInEachMonth[month];
        month++;
    }
    else
    {
        day = day + numOfDays;
    }
}


void Date::restHunting()
{
    if(day + 1 > numDaysInEachMonth[month])
    {
        day = day + 1 - numDaysInEachMonth[month];
        month++;
    }
    else
    {
        day = day + 1;
    }
}
