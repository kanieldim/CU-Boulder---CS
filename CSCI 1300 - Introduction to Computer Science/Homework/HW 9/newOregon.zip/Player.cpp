#include <string>
#include "Player.h"

using namespace std;

Player::Player()
{

    mainPlayer = 0;
    sick = 0;
}

void Player::setPlayerID(int playerIDAssigned)
{
    playerID = playerIDAssigned;
}

void Player::setPlayerName(string nameAssigned)
{
    playerName = nameAssigned;
}
