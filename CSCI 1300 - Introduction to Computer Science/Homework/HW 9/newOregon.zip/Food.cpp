#include "Food.h"

using namespace std;

Food::Food()
{
    totalFood = 0;
    randomFood = 0;
}

void Food::setTotalFood(int Food)
{
    totalFood = Food;
}

void Food::addFood(int MoreFood)
{
    totalFood = totalFood + MoreFood;
}

void Food::restFood(int numPlayers, int numDays)
{
    totalFood = totalFood - 3 * numPlayers * numDays;
}

void Food::rabbitFood()
{
    totalFood = totalFood + 2;
}

void Food::foxFood()
{
    totalFood = totalFood + 5;
}

void Food::deerFood()
{
    randomFood = rand()%26 + 30;
    totalFood = totalFood + randomFood;
}

void Food::bearFood()
{
    randomFood = rand()%251 + 100;
    totalFood = totalFood + randomFood;
}

void Food::mooseFood()
{
    randomFood = rand()%301 + 300;
    totalFood = totalFood + randomFood;
}

