#include "MiscSupplies.h"

using namespace std;

MiscSupplies::MiscSupplies()
{
    numParts = 0;
    numKits = 0;
}

void MiscSupplies::setNumParts(int numOfParts)
{
    numParts = numOfParts;
}
void MiscSupplies::addNumParts(int numOfParts)
{
    numParts = numParts + numOfParts;
}
void MiscSupplies::setNumKits(int numOfKits)
{
    numKits = numOfKits;
}
void MiscSupplies::addNumKits(int numOfKits)
{
    numKits = numKits + numOfKits;
}
