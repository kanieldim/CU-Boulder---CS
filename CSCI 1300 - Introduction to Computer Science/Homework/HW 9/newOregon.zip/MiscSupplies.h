#include <iostream>

#ifndef MISCSUPPLIES_H
#define MISCSUPPLIES_H

class MiscSupplies
{
    int numParts;
    int numKits;

    public:
    
    MiscSupplies();
    void setNumParts(int);
    void addNumParts(int);
    int getNumParts() { return numParts; };
    void setNumKits(int);
    void addNumKits(int);
    int getNumKits() { return numKits; };

};

#endif
