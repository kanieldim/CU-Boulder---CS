#include <iostream>
#include "Player.h"
#include "Food.h"
#include "Bullets.h"
#include "Oxen.h"
#include "MiscSupplies.h"

#ifndef OREGONTRAIL_H
#define OREGONTRAIL_H

class OregonTrail
{
    Player players[5];
    Food food;
    Oxen oxen;
    Bullets bullets;
    MiscSupplies miscSupplies;
    
    int numPlayers;
    int mainPlayer;
    
    int visitStoreCnt;
    int numWagon;
    int numYokes;
    int numOxen;
    int poundsFood;
    int numBoxes;
    int numBullets;
    int numParts;
    int numKits;
    
    float priceWagon;
    float priceYokes;
    float priceOxen;
    float priceFood;
    float priceBoxes;
    float priceParts;
    float priceKits;

    float totalCash;
    float currentBill;
    float categoryBill;
    int numCategory;
    int numCategoryOxen;
    int numCategoryParts;
    int numCategoryKits;
    
    float currMileOntrip;
    
    public:
    
    OregonTrail();
    
    int addPlayer(int, string);
    string getPlayerName(int);
    int getNumPlayers() { return numPlayers; };
    void sickness(int);

    void setNumWagon(int);
    void setNumYokes(int);
    void setNumOxen(int);
    void setPoundsFood(int);
    void setNumBoxes(int);
    void setNumBullets(int);
    void setNumParts(int);
    void setNumKits(int);

    void setPriceWagon(float);
    void setPriceYokes(float);
    void setPriceOxen(float);
    void setPriceFood(float);
    void setPriceBoxes(float);
    void setPriceParts(float);
    void setPriceKits(float);
    
    void addVisitStoreCnt();
    void addNumWagon(int);
    void addNumYokes(int);
    void addtNumOxen(int);
    void addPoundsFood(int);
    void addNumBoxes(int);
    void addNumBullets(int);
    void addNumParts(int);
    void addNumKits(int);
    
    int getVisitStoreCnt() { return visitStoreCnt; };
    int getNumWagon() { return numWagon; };
    int getNumYokes() { return numYokes; };
    int getNumOxen() { return numOxen; };
    int getPoundsFood() { return poundsFood; };
    int getNumBoxes() { return numBoxes; };
    int getNumBullets() { return numBullets; };
    int getNumParts() { return numParts; };
    int getNumKits() { return numKits; };
    
    void setTotalCash(float);
    void setCurrentBill(float);
    float getTotalCash() { return totalCash; };
    float getCurrentBill(void) { return currentBill; }
    
    void payMoney(void);
    void printBill(void);
    void resetCategoryBill(void);
    void returnCategory(void);

    int getCurrMileOnTrip() { return currMileOntrip; };
    
    void visitStoreFirst();
    //void statusUpdate();
    //int hunt();
    //void misfortunes();
    //void raiderAttack();
    //bool puzzles();
    
};

#endif
