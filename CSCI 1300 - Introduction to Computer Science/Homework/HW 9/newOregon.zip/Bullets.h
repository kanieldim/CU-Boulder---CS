#include <iostream>

#ifndef BULLETS_H
#define BULLETS_H

class Bullets
{
    int totalBoxes;
    int totalBullets;
    
    public:
    
    Bullets();
    void setBoxesCount(int);
    void setBulletsCount(int);
    void addBoxesCount(int);
    void addBulletsCount(int);
    void subBulletsCount(int);
    int getBoxesCount() {return totalBoxes;};
    int getBulletsCount() {return totalBullets;};
    void huntRabbit();
    void huntFox();
    void huntDeer();
    void huntBear();
    void huntMoose();

};

#endif
