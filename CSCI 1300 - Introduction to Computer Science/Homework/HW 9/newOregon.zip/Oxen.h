#include <iostream>

#ifndef OXEN_H
#define OXEN_H

class Oxen
{
    int numWagon;
    int numOxen;
    int numYokes;
    
    public:
    
    Oxen();
    void setNumWagon(int);
    void addNumWagon(int);
    void brokenWagon();
    void setNumYokes(int);
    void addNumYokes(int);
    void brokenYokes();
    void setNumOxen(int);
    void addNumOxen(int);
    void deadOxen();
    
};

#endif
