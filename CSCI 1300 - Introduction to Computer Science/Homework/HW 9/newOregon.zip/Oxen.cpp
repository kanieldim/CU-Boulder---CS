#include "Oxen.h"

using namespace std;

Oxen::Oxen()
{
    numWagon = 0;
    numOxen = 0;
    numYokes = 0;
}

void Oxen::setNumWagon(int numOfWagon)
{
    numWagon = numOfWagon;
}

void Oxen::addNumWagon(int numOfYokes)
{
    numWagon = numWagon + numOfWagon;
}

void Oxen::brokenWagon()
{
    numWagon = numWagon - 1;
}

void Oxen::setNumYokes(int numOfYokes)
{
    numYokes = numOfYokes;
}

void Oxen::addNumYokes(int numOfYokes)
{
    numYokes = numYokes + numOfYokes;
}

void Oxen::brokenYokes()
{
    numYokes = numYokes - 1;
}

void Oxen::setNumOxen(int numOfOxen)
{
    numOxen = numOfOxen;
}

void Oxen::addNumOxen(int numOfOxen)
{
    numOxen = numOxen + numOfOxen;
}

void Oxen::deadOxen()
{
    numOxen = numOxen - 1;
}
