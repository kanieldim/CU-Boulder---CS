#include <iostream>

#ifndef FOOD_H
#define FOOD_H

class Food
{
    int totalFood;
    int randomFood;
    
    public:
    
    Food();
    int getTotalFood() {return totalFood;};
    void setTotalFood(int); 
    void addFood(int);
    void restFood(int, int);
    void rabbitFood();
    void foxFood();
    void deerFood();
    void bearFood();
    void mooseFood();
};

#endif
