#include <iostream>
//#include "Food.h"

using namespace std;

#ifndef PLAYER_H
#define PLAYER_H

class Player
{
    int playerID;
    string playerName;
    
    int mainPlayer = 0;
    int sick = 0;
    
    
    public:
    
    Player();
    
    void setPlayerID(int);
    void setPlayerName(string);
    string getPlayerName() { return playerName; };
    void iamSick() { sick = 1; };
    void setMainPlayer() { mainPlayer = 1; };
};

#endif
