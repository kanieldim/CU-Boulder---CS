#include <iostream>
#include <fstream>
#include <sstream>

using namespace std;

#define MAX_WORD_LENGTH 100
#define MAX_BOOK_COUNT 50
#define MAX_RATING_COUNT 100
#define MAX_USER_COUNT 100
#define MAX_STRING_LENGTH 100

int split ( string line, char del, string words[], int maxCount )
{
    int wordCount = 0;
    int i, j = 0;
    int lineLength = 0;
    char oneWord[MAX_WORD_LENGTH];
    string aWordStart = "ON";
    
    lineLength = line.length();
    
    for ( i = 0; i < lineLength; i++ )
    {
        if ( line[i] != del && aWordStart == "ON" ) {
            wordCount++;
            while ( line[i] != del ) {
                oneWord[j] = line[i];
                if ( i == lineLength ) {
                    break;
                }
                i++; j++;
            }
            oneWord[j] = '\0';
            words[wordCount-1] = oneWord;
            
            //cout << "word " << wordCount << ": " << words[wordCount-1] << endl;
            
            j = 0; i--;
            aWordStart = "OFF";
        }
        
        if (line[i] == del) {
            aWordStart = "ON";
        }
    }
    return wordCount;
}

int readRatings (string file, string userNames[], int listRatings[MAX_USER_COUNT][MAX_RATING_COUNT], int nofUsers, int rowCapacity, int columnCapacity )
{
    int userCnt = 0;
    int columns = 0;
    int lists;
    string line = "";
    string userRating[2];
    string ratings[MAX_USER_COUNT];
    string ratingStr[MAX_RATING_COUNT];

    ifstream inFile;
    inFile.open(file);
    
    if(!inFile.is_open())
	{
        return -1;
    }
    while (getline(inFile, line)) 
	{
        columns = split (line, ',', userRating, 2);
        userNames[userCnt] = userRating[0];
        ratings[userCnt] = userRating[1];
        lists = split (ratings[userCnt], ' ', ratingStr, MAX_RATING_COUNT);
        cout << userCnt+1 << " - " << userNames[userCnt] << ", list of ratings ( " << lists << " )" << " = ";
        for (int i = 0; i < lists; i++) {
            listRatings[userCnt][i] = stoi (ratingStr[i]);
            cout << listRatings[userCnt][i] << ", ";
        }
        cout << endl;
        userCnt++;
    }
    
    inFile.close();
    
    if (userCnt == nofUsers)
        //cout << " READ ALL!" << endl;
    
    return userCnt;
}

int main ( )
{
    int userCount;
    string userNames[MAX_USER_COUNT];
    int listRatings[MAX_USER_COUNT][MAX_RATING_COUNT];
    
    for ( int i = 0; i < MAX_USER_COUNT; i++ ) {
        for ( int j = 0; j < MAX_RATING_COUNT; j++ ) {
            listRatings[i][j] = 0;
        }
    }
    cout << "start!" << endl;
    userCount = readRatings ("ratings.txt", userNames, listRatings, MAX_USER_COUNT, MAX_USER_COUNT, MAX_RATING_COUNT );
    cout << "GOT ALL " << userCount << " USERs!" << endl;
    
    return 0;
}