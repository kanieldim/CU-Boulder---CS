#include <iostream>
#include <fstream>
#include <sstream>

using namespace std;

#define MAX_WORD_LENGTH 100
#define MAX_BOOK_COUNT 50
#define MAX_RATING_COUNT 100
#define MAX_USER_COUNT 100
#define MAX_STRING_LENGTH 100

int split ( string line, char del, string words[], int maxCount )
{
    int wordCount = 0;
    int i, j = 0;
    int lineLength = 0;
    char oneWord[MAX_WORD_LENGTH];
    string aWordStart = "ON";
    
    lineLength = line.length();
    
    for ( i = 0; i < lineLength; i++ )
    {
        if ( line[i] != del && aWordStart == "ON" ) {
            wordCount++;
            while ( line[i] != del ) {
                oneWord[j] = line[i];
                if ( i == lineLength ) {
                    break;
                }
                i++; j++;
            }
            oneWord[j] = '\0';
            words[wordCount-1] = oneWord;
            
            //cout << "word " << wordCount << ": " << words[wordCount-1] << endl;
            
            j = 0; i--;
            aWordStart = "OFF";
        }
        
        if (line[i] == del) {
            aWordStart = "ON";
        }
    }
    return wordCount;
}

int readBooks (string file, string titles[], string authors[], int nofBooks, int capacity)
{
    int bookCnt = 0;
    int columns = 0;
    string line = "";
    string authorTitle[2];
    
    ifstream inFile;
    inFile.open(file);
    
    if(!inFile.is_open()) 
    {
            return -1;
    }
    
    while (getline(inFile, line)) 
    {
        columns = split ( line, ',', authorTitle, 2 );
        titles[bookCnt] = authorTitle[1];
        authors[bookCnt] = authorTitle[0];
        cout << "book" << bookCnt << ": title = " << titles[bookCnt]
                                  << ", author = " << authors[bookCnt] << endl;
        bookCnt++;
    }
    
    inFile.close();
    
    if (bookCnt == nofBooks)
    {
        cout << " READ ALL!" << endl;
    }
    
    return bookCnt;
}

void printAllBooks (string titles[], string authors[]. int nofBooks)
{
    if (nofBooks == 0)
    {
        cout << "No books are stored" << endl;
    }
    
    cout << "Here is a list of books" << endl;
    for ( int i = 0; i < nofBooks; i++)
    {
        cout << titles[i] << " by " << authros[i] << endl;
    }
}

int main ()
{
    int bookCount;
    string titles[MAX_BOOK_COUNT];
    string authors[MAX_BOOK_COUNT];
    
    bookCount = readBooks ( "/Users/pio/Desktop/C++Programming/hw6/hw6 q1/hw6 q1/books.txt", titles, authors, MAX_BOOK_COUNT, MAX_BOOK_COUNT );

    printAllBooks ( titles, authors, bookCount );
}