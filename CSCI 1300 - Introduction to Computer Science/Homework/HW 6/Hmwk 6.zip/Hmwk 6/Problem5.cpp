double calcAverage (string aBookTitle, string titles[], int listRatings[MAX_USER_COUNT][MAX_RATING_COUNT], int userCount, int bookCount)
{
    int readCount = 0;
    int ratingSum = 0;
    double avgRating = 0.0;
    
    if (userCount == 0)
    {
        return -1;
    }
    
    for (int i = 0; i < bookCount; i++)
    {
        if (titles[i].compare(aBookTitle) == 0)
        {
            for (int n = 0; n < userCount; n++)
            {
                ratingSum = ratingSum + listRatings[n][i]; // summing up all the users' rating for a particular book
                // cout << listRatings[n][i] << " ";
                if (listRatings[n][i] > 0) // summing up the read/reviewed users
                {
                    readCount++;
                }
            }
            avgRating = ratingSum / (double) readCount; // calculating the average rating
            cout << "The average rating for " << aBookTitle << " is " << avgRating << endl;
            break;
        }
    }
    
    return avgRating;
}