#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <string>
using namespace std;

#define MAX_BOOK_COUNT 50   // defining the maximum number of books stored in the books file
#define MAX_USER_COUNT 100  // defining the maximum number of read/review-users stored in the ratings file
#define MAX_RATING_COUNT 50 // defining the maximum number of book-ratings stored in the ratings file
#define YES 1
#define NO 0


int getUserReadCount ( string aUserName, string userNames[], int listRatings[MAX_USER_COUNT][MAX_RATING_COUNT], int userCount, int bookCount )
{
    int bookCntBytheUser = 0;
    
    for ( int i = 0; i < userCount; i++ )
    {
        if ( userNames[i].compare(aUserName) == 0 ) // searching a particular user in the read/reviewed users
        {
            for ( int n = 0; n < bookCount; n++ ) // finding the number of books the user rated
            {
                if ( listRatings[i][n] > 0 ) // rating 0 : Did not read, rating 1 ~ 5 : read and reviewed
                {
                    bookCntBytheUser++;
                }
            }
        }
        else
        {
            return -1;
        }
    }
    
    return bookCntBytheUser;
}