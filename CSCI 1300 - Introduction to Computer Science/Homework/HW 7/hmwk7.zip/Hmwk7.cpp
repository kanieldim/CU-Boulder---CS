#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>

#include "Book.h"
#include "User.h"

using namespace std;


/* split function
 * the function to split the given string into array of string with respect to a delimiter
 *
 * @param : string , the string we are going to split
 * @param : char, the delimiter
 * @param : string array, the array of string we save after spliting
 * @param : int, size of the  indicates the maximum number of split-apart string pieces
 */
int split (string str, char c, string array[], int size)
{
    if (str.length() == 0) {
        return 0;
    }
    string word = "";
    int count = 0;
    str = str + c;
    for (int i = 0; i < str.length(); i++)
    {
        if (str[i] == c)
        {
            if (word.length() == 0)
                continue;
            array[count++] = word;
            word = "";
        } else {
            word = word + str[i];
        }
    }
    return count ;
}


/* readBooks function
 * the function reads a book file from the text into book and author arrays
 *
 * @param: string, the name of the file to be read
 * @param: string array, titles
 * @param: string array, authors
 * @param: int, the number of books currently stored in the arrays
 * @param: int, capacity of the authors/titles arrays [assume to be 50]
 * @return: the total number of books in total
 */

//////////////////////////////////////////////////////////////////////////
// ToDo: implement readBooksfunction
int readBooks (string nameFile, Book bookOne[], int numBooks, int capacity)
{
    
    ifstream inFile;
    int columns = 0;
    string line = "";
    string authorTitle[2];
    string title;
    string author;
    
    inFile.open(nameFile);
    
    if( !inFile.is_open() ) {
        return -1;
    }
    
    while ( getline(inFile, line) )
    {
        columns = split ( line, ',', authorTitle, 2 ); // spliting the line to author and title by using comma delimiter
        author = authorTitle[0]; // storing an author to the array, authors
        title = authorTitle[1];  // storing a title to the array, titles
        
        bookOne[numBooks].setTitle ( title );
        bookOne[numBooks].setAuthor ( author );
        
        numBooks++;
    }
    
    inFile.close();
    
    return numBooks; // returing the number of books stored in the books file
}

//////////////////////////////////////////////////////////////////////////


/* readRatings function
 * Read the user ratings from the file and store them
 * into users array and ratings array
 *
 * @param: string, the name of the file to be read
 * @param: string array, usernames
 * @param: 2D int array, list of ratings for each user (first index specifies user)
 * @param: int, the number of users currently stored in the array
 * @param: int, row capacity of the 2D array (convention: array[row][column]) [assume to be 100]
 * @param: int, column capacity of the 2D array [assume to be 50]
 * @return: the number of users in total
 */

//////////////////////////////////////////////////////////////////////////
// ToDo: implement readRatings function
int readRatings (string nameFile, User userOne[], int numUsers, int capacity )
{
    ifstream inFile;
    int columns = 0;
    int lists;
    string line = "";
    string userRating[2];
    
    string ratingStr[capacity];
    
    inFile.open(nameFile);
    
    if( !inFile.is_open() )
    {
        return -1;
    }
    while ( getline(inFile, line) )
    {
        string ratings;
        columns = split ( line, ',', userRating, 2 ); // spliting the line user's name and the list of ratings
        userOne[numUsers].setUsername(userRating[0]); // storing a user name to the array, userNames
        //ratings[numUsers] = u;   // storing a user's ratings-list to the array, ratings
        cout << userOne[numUsers].getUsername() << "..." << endl;
        lists = split ( userRating[1], ' ', ratingStr, capacity ); // spliting the ratings-list in the array, ratingStr
        for ( int i = 0; i < lists; i++ ) {
            userOne[numUsers].setRatingAt(i, stoi(ratingStr[i])); // converting each ratingStr to a rating in the array, listRatings
            //cout << userOne[numUsers].getRatingAt(i) << " ";
        }
        
        numUsers++;
    }
    
    inFile.close();
    
    return numUsers; // returing the number of read/reviewed users stored in the ratings file
}


//////////////////////////////////////////////////////////////////////////

/* printAllBooks function
 * the function display the contents of the books
 *
 * @param: string array, titles
 * @param: string array, authors
 * @param: int, the number of books currently stored in the arrays
 * @return: no return
 */

//////////////////////////////////////////////////////////////////////////
// ToDo: implement printAllBooks function
void printAllBooks ( Book bookOne[], int numBooks )
{
    
    if ( numBooks <= 0 )
    {
        cout << "No books are stored" << endl;
        cout << endl;
        return;
    }
    
    cout << "Here is a list of books" << endl;
    for ( int i = 0; i < numBooks; i++ )
    {
        cout << bookOne[i].getTitle() << " by " << bookOne[i].getAuthor() << endl;
    }
    
}

/* displayMenu:
 * displays a menu with options
 * DO NOT MODIFY THIS FUNCTION
 */
void displayMenu(){
    cout << "Select a numerical option: " << endl;
    cout << "======Main Menu=====" << endl;
    cout << "1. Read book file" << endl;
    cout << "2. Read user file" << endl;
    cout << "3. Print book list" << endl;
    cout << "4. Find number of books user rated" << endl;
    cout << "5. Get average rating" << endl;
    cout << "6. Quit" << endl;
    
}


int main(int argc, char const *argv[]) {
    string choice;
    int booksFileOpened = 0;
    int ratingsFileOpened = 0;
    int numBooks = 0;
    int numUsers = 0;
    
    string booksFILE;
    string ratingsFILE;
    string aUserName = "";
    int numReads = 0;
    
    Book bookOne[200];
    User userOne[200];
    
    
    while (choice != "6") {
        displayMenu();
        getline(cin, choice);
        switch (stoi(choice)) {
            case 1:
                // read book file
                cout << "Enter a book file name: " << endl;
                
                //////////////////////////////////////////////////////////////////////////
                getline(cin, booksFILE);
                numBooks = readBooks ( booksFILE, bookOne, numBooks, 200 );
                if ( numBooks == -1 )
                {
                    cout << "No books saved to the database" << endl;
                    booksFileOpened = 0;
                    cout << endl;
                    break;
                }
                else
                    booksFileOpened = 1;
                //////////////////////////////////////////////////////////////////////////
                
                cout << "Total books in the database: " << numBooks << endl;
                cout << endl;
                break;
                
            case 2:
                // read user file
                cout << "Enter a rating file name: " << endl;
                
                //////////////////////////////////////////////////////////////////////////
                getline(cin, ratingsFILE);
                numUsers = readRatings ( ratingsFILE, userOne, numUsers, 200);
                if ( numUsers == -1 )
                {
                    cout << "No users saved to the database" << endl;
                    ratingsFileOpened = 0;
                    cout << endl;
                    break;
                }
                else
                    ratingsFileOpened = 1;
                //////////////////////////////////////////////////////////////////////////
                
                cout << "Total users in the database: " << numUsers << endl;
                cout << endl;
                break;
                
            case 3:
                // print the list of the books
                
                //////////////////////////////////////////////////////////////////////////
                if ( booksFileOpened == 0 )
                    cout << "No books are stored" << endl;
                else
                    printAllBooks ( bookOne, numBooks );
                //////////////////////////////////////////////////////////////////////////
                
                cout << endl;
                break;
            /*
            case 4:
                
                // find the number of books user read
                cout << "Enter username: ";
                
                //////////////////////////////////////////////////////////////////////////
                getline( cin, aUserName );
                //numReads = getUserReadCount ( aUserName, userNames, listRatings, numUsers, MAX_RATING_COUNT );
                
                if ( numReads == -1 )
                    cout << aUserName << " does not exist in the database" << endl;
                else
                    cout << aUserName << " rated " << numReads << " books" << endl;
                //////////////////////////////////////////////////////////////////////////
                
                cout << endl;
                break;
                
            case 5:
                // get the average rating of the book
                cout << "Enter book title: ";
                
                //////////////////////////////////////////////////////////////////////////
                getline(cin, aBookTitle );
                //avgRating = calcAvgRating ( aBookTitle, titles, listRatings, numUsers, numBooks );
                
                if ( avgRating == -1 )
                    cout << "The book (" << aBookTitle << ") does not exist in the database" << endl;
                else
                {
                    cout << fixed << setprecision(2);
                    cout << "The average rating for " << aBookTitle << " is " << avgRating << endl;
                }
                //////////////////////////////////////////////////////////////////////////
                
                cout << endl;
                break;
            */
            case 6:
                // quit
                cout << "good bye!" << endl;
                break;
                
            default:
                cout << "invalid input" << endl << endl;
        }
    }
    
    return 0;
}
