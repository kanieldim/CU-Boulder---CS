#ifndef BOOK_H
#define BOOK_H

using namespace std;

class Book
{
    string title;
    string author;
    
    public:
        Book();
        Book (string, string);
        string getTitle() {return title;};
        void setTitle(string);
        string getAuthor() {return author;};
        void setAuthor(string);
};

#endif
