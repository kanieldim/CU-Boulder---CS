#include <string>
#include "Book.h"

Book::Book()
{
    title = "";
    author = "";
}

Book::Book (string titleA, string authorA)
{
    title = titleA;
    author = authorA;
}

void Book::setTitle(string titleA)
{
    title = titleA;
}

void Book::setAuthor(string authorA)
{
    author = authorA;
}
