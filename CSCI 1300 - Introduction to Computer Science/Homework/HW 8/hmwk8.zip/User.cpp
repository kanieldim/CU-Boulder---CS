#include <string>
#include "User.h"

using namespace std;

User::User()
{
    username = "";
    numRatings = 200;
    size = 200;
    
    for ( int i = 0; i < 200; i++ ) {
        ratings[i] = -1;
    }
}

User::User ( string usernameA, int ratingsA[], int numRatingsA )
{
    username = usernameA;
    for ( int i = 0; i < numRatingsA; i++ ) {
        ratings[i] = ratingsA[i];
    }
    numRatings = numRatingsA;
    size = 200;
}

void User::setUsername(string usernameA)
{
    username = usernameA;
}

int User::getRatingAt(int index)
{
    if (index >= numRatings)
    {
        return -1;
    }
    return ratings[index];
}

bool User::setRatingAt(int index, int value)
{
    bool result = false;
    if (index >= 0 && index <= 200)
    {
        if (value >= 0 && value <=5)
        {
            ratings[index] = value;
            result = true;
        }
    }
    return result;
}

void User::setNumRatings(int numRatingsA)
{
    numRatings = numRatingsA;
}
