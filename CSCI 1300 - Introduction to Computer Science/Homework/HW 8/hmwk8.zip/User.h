#include <string>

#ifndef USER_H
#define USER_H

using namespace std;

class User
{
    string username;
    int ratings[200];
    int numRatings;
    int size;
    
 public:
    User();
    User (string, int [], int);
    
    string getUsername() {return username;};
    void setUsername(string);
    int getRatingAt(int);
    bool setRatingAt(int, int);
    int getNumRatings() {return numRatings;};
    void setNumRatings (int);
    int getSize() {return size;};
};

#endif