#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <string>
#include <math.h>

#include "Book.h"
#include "User.h"
#include "Library.h"


using namespace std;




void displayMenu(){
    cout << "Select a numerical option: " << endl;
    cout << "======Main Menu=====" << endl;
    cout << "1. Read book file" << endl;
    cout << "2. Read user file" << endl;
    cout << "3. Print book list" << endl;
    cout << "4. Find number of books user rated" << endl;
    cout << "5. Get average rating" << endl;
    cout << "6. Add a User" << endl;
    cout << "7. Checkout a book" << endl;
    cout << "8. View Ratings" << endl;
    cout << "9. Get Recommendations" << endl;
    cout << "10. Quit" << endl;
    
}

int main(int argc, char const *argv[]) 
{
    string choice;
    int booksFileOpened = 0;
    int ratingsFileOpened = 0;
    int numBooks = 0;
    int numUsers = 0;
    double avgRating = 0.0;
    bool result;
    int aNewRating;
    Library lib;
    string tempRating;

    string aBookTitle;
    string booksFILE;
    string ratingsFILE;
    string aUserName = "";
    int numReads = 0;
    
    Book bookOne[200];
    User userOne[200];
    
    
    while (choice != "10") 
    {
        displayMenu();
        getline(cin, choice);
        switch (stoi(choice)) 
        {
            case 1:
                // read book file
                cout << "Enter a book file name: " << endl;
                
                //////////////////////////////////////////////////////////////////////////
                getline(cin, booksFILE);
                numBooks = lib.readBooks ( booksFILE );
                //cout << numB
                if ( numBooks == -1 )
                {
                    cout << "No books saved to the database" << endl;
                    booksFileOpened = 0;
                    cout << endl;
                    break;
                }
                else
                    booksFileOpened = 1;
                //////////////////////////////////////////////////////////////////////////
                
                cout << "Total books in the database: " << numBooks << endl;
                cout << endl;
                break;
                
            case 2:
                // read user file
                cout << "Enter a rating file name: " << endl;
                
                //////////////////////////////////////////////////////////////////////////
                getline(cin, ratingsFILE);
                numUsers = lib.readRatings (ratingsFILE);
                if ( numUsers == -1 )
                {
                    cout << "No users saved to database" << endl;
                    ratingsFileOpened = 0;
                    cout << endl;
                    break;
                }
                else
                    ratingsFileOpened = 1;
                //////////////////////////////////////////////////////////////////////////
                
                cout << "Total users in the database: " << numUsers << endl;
                cout << endl;
                break;
                
            case 3:
                // print the list of the books
                
                //////////////////////////////////////////////////////////////////////////
                lib.printAllBooks();
                //////////////////////////////////////////////////////////////////////////
                
                cout << endl;
                break;
            
            case 4:
                
                // find the number of books user read
                cout << "Enter username: " << endl;
                
                //////////////////////////////////////////////////////////////////////////
                getline( cin, aUserName );
                numReads = lib.getCountReadBooks ( aUserName );
                if (numReads != -1 && numReads != -2)
                {
                    cout << aUserName << " rated " << numReads << " books" << endl;
                }
                //////////////////////////////////////////////////////////////////////////
                
                cout << endl;
                break;
                
            case 5:
                // get the average rating of the book
                cout << "Enter book title: " << endl;
                
                //////////////////////////////////////////////////////////////////////////
                getline(cin, aBookTitle );
                avgRating = lib.calcAvgRating ( aBookTitle );
                
                if (avgRating != -1 && avgRating != -2)
                {
                    cout << fixed << setprecision(2);
                    cout << "The average rating for " << aBookTitle << " is " << avgRating << endl;
                }
                //////////////////////////////////////////////////////////////////////////
                
                cout << endl;
                break;
            
            case 6:
                cout << "Enter username: " << endl;
                
                getline(cin, aUserName);
                result = lib.addUser(aUserName);
                if (result == true)
                {
                    cout << "Welcome to the library " << aUserName << endl; 
                    cout << endl;
                }
                else
                {
                    cout << aUserName << " could not be added in the database" << endl;
                    cout << endl;
                }
                
                break;
            
            case 7:
                cout << "Enter username: " << endl;
                getline(cin, aUserName);
                cout << "Enter book title: " << endl;
                getline(cin, aBookTitle);
                cout << "Enter rating for the book: " << endl;
                getline(cin, tempRating);
                
                aNewRating = stoi(tempRating);
                
                
                result = lib.checkOutBook (aUserName, aBookTitle, aNewRating);
                
                if (result == true)
                {
                    cout << "We hope you enjoyed your book. The rating has been updated" << endl;
                    cout << endl;
                }
                else
                {
                    cout << aUserName << " could not check out " << aBookTitle << endl;
                    cout << endl;
                }
                
                break;
            
            case 8:
                cout << "Enter username: " << endl;
                getline(cin, aUserName );
                lib.viewRatings (aUserName);
                break;
                
            case 9:
                cout << "Enter username: " << endl;
                getline(cin, aUserName );
                lib.getRecommendations( aUserName );
                break;
                
            case 10:
                // quit
                cout << "good bye!" << endl;
                break;
                
            default:
                cout << "invalid input" << endl << endl;
        }
    }
    
    return 0;
}

