#ifndef LIBRARY_H
#define LIBRARY_H
#include "Book.h"
#include "User.h"
#include <math.h>

using namespace std;

class Library
{
    Book books[200];
    User users[200];
    int numBooks;
    int numUsers;
    int sizeBook;
    int sizeUser;
    
    public:
        Library();
        
        int readBooks(string);
        int readRatings(string);
        void printAllBooks();
        int getCountReadBooks(string);
        double calcAvgRating(string);
        bool addUser(string);
        bool checkOutBook(string, string, int);
        void viewRatings(string);
        void getRecommendations(string);
        
};

#endif