#include "Book.h"
#include "User.h"
#include "Library.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <string>

using namespace std;


Library::Library()
{
    numBooks = 0;
    numUsers = 0;
}

int split (string str, char c, string array[], int size)
{
    if (str.length() == 0) 
    {
        return 0;
    }
    string word = "";
    int count = 0;
    str = str + c;
    for (int i = 0; i < str.length(); i++)
    {
        if (str[i] == c)
        {
            if (word.length() == 0)
                continue;
            array[count++] = word;
            word = "";
        } 
        else {
            word = word + str[i];
        }
    }
    return count ;
}


int Library::readBooks(string nameFile)
{
    int columns = 0;
    string line = "";
    string authorTitle[2];
    string title;
    string author;
    
    
    
    ifstream inFile;
    inFile.open(nameFile);
    
    
    if( !inFile.is_open() )
    {
        return -1;
    }
    
    while ( getline(inFile, line) && numBooks < 200)
    {
        columns = split ( line, ',', authorTitle, 2 ); // spliting the line to author and title by using comma delimiter
        author = authorTitle[0]; // storing an author to the array, authors
        title = authorTitle[1];  // storing a title to the array, titles
        
        books[numBooks].setTitle ( title );
        books[numBooks].setAuthor ( author );
        
        numBooks++;
    }
    
    inFile.close();
    
    return numBooks;
}

int Library::readRatings(string nameFile)
{
    int columns = 0;
    int lists;
    string line = "";
    string userRating[2];
    string ratings;
    string ratingStr[200];
    
    ifstream inFile;
    inFile.open(nameFile);
    
    if( !inFile.is_open() )
    {
        return -1;
    }
    while ( getline(inFile, line) && numUsers < 200 )
    {
        columns = split ( line, ',', userRating, 2 ); // spliting the line user's name and the list of ratings
        users[numUsers].setUsername(userRating[0]); // storing a user name to the array, userNames
        cout << users[numUsers].getUsername() << "..." << endl;
        lists = split ( userRating[1], ' ', ratingStr, 200 ); // spliting the ratings-list in the array, ratingStr
        for ( int i = 0; i < lists; i++ )
        {
            users[numUsers].setRatingAt(i, stoi(ratingStr[i])); // converting each ratingStr to a rating in the array, listRatings
        }
        
        numUsers++;
    }
    
    inFile.close();
    
    return numUsers;
}

void Library::printAllBooks()
{
    if ( numBooks <= 0 )
    {
        cout << "Database has not been fully initialized" << endl;
        return;
    }
    
    cout << "Here is a list of books" << endl;
    for ( int i = 0; i < numBooks; i++ )
    {
        cout << books[i].getTitle() << " by " << books[i].getAuthor() << endl;
    }
    
}

int Library::getCountReadBooks (string name)
{
    int bookCntBytheUser = 0;
    string names;
    string userName;
    int usernameFound = 0;
    int UserID = 0;
    
    if (numBooks == 0 || numUsers == 0)
    {
        cout << "Database has not been fully initialized" << endl;
        return -1;
    }
    
    for (int i = 0; i <= numUsers; i++)
    {
        names = users[i].getUsername();
        if ( names.compare(name) == 0)
        {
            usernameFound = 1;
            UserID = i;
        }
    }
    if (users[UserID].getNumRatings() == 0)
    {
        cout << name << " rated 0 books" << endl;
        return users[UserID].getNumRatings();
    }
        
    if (usernameFound == 0)
    {
        cout << name << " does not exist in the database" << endl;
        return -2;
    }
    
    for ( int i = 0; i < numUsers; i++ )
    {
        userName = users[i].getUsername();
        if ( userName.compare(name) == 0 ) // searching a particular user in the read/reviewed users
        {
            for ( int n = 0; n < numBooks; n++ ) // finding the number of books the user rated
            {
                if ( users[i].getRatingAt(n) > 0 ) // rating 0 : Did not read, rating 1 ~ 5 : read and reviewed
                {
                    bookCntBytheUser++;
                }
            }
            
        }
    }
    
    return bookCntBytheUser;
}

double Library::calcAvgRating(string bookTitle)
{
    int readCount = 0;
    int ratingSum = 0;
    double avgRating = 0.0;
    string title;
    string names;
    
    if (numBooks == 0 || numUsers == 0)
    {
        cout << "Database has not been fully initialized" << endl;
        return -1;
    }
    
    // for (int i = 0; i <= numBooks; i++)
    // {
    //     title = books[i].getTitle();
    //     if (title.compare(bookTitle) != 0)
    //     {
    //         cout << bookTitle << " does not exist in the database" << endl;
    //         return -2;
    //     }
    // }
    
    
    for (int i = 0; i <= numBooks; i++)
    {
        title = books[i].getTitle();
        if (title.compare(bookTitle) == 0)
        {
            for (int n = 0; n < numUsers; n++)
            {
                ratingSum = ratingSum + users[n].getRatingAt(i); // summing up all the users' rating for a particular book
                if (users[n].getRatingAt(i) > 0) // summing up the read/reviewed users
                {
                    readCount++;
                }
            }
            avgRating = ratingSum / (double) readCount; // calculating the average rating
        }
        else if (title.compare(bookTitle) != 0)
        {
            cout << bookTitle << " does not exist in the database" << endl;
            return -2;
        }
        // else
        // {
        //     cout << bookTitle << " does not exist in the database" << endl;
        //     return -2;
        // }
    }
    
    return avgRating;
}

bool Library::addUser (string name)
{
    string Username;
    int check=0;
    int ci;
    string lowerName;
    
    if ((numUsers + 1) > 200)
    {
        cout << "Database full" << endl;
        return false;
    }
    for ( ci = 0; ci < name.length(); ci++ )
    {
        lowerName += tolower(name[ci]);
    }
    //lowerName = '\0';
    
    for (int i = 0; i < numUsers; i++)
    {
        Username = users[i].getUsername();
        if (Username.compare(lowerName) == 0)
        {
            check = 1;
            cout << name << " already exists in the database" << endl;
            return false;
        }
            
    }
    
    users[numUsers].setUsername(lowerName);
    
    if (check == 0)
    {
        numUsers = numUsers+1;
        users[numUsers].setUsername(name);
        users[numUsers].setNumRatings(0);
    }
    
    // for ( int i = 0; i < numBooks; i++ )
    // {
    //     users[numUsers].setRatingAt(i, 0);
    // }
        

    
    
    return true;
}

bool Library::checkOutBook(string name, string bookTitle, int newRating)
{
    string names;
    string title;
    int UserID = 200;
    int BookID = 200;
    int usernameFound = 0;
    int booktitleFound = 0;
    int theUserNumRatings = 0;
    bool result;
    
    if (numBooks == 0 || numUsers == 0)
    {
        cout << "Database has not been fully initialized" << endl;
        return false;
    }
    
    for (int i = 0; i < numUsers; i++)
    {
        names = users[i].getUsername();
        if ( names.compare(name) == 0)
        {
            usernameFound = 1;
            UserID = i;
            break;
        }
    }
    
    if (usernameFound == 0)
    {
        cout << name << " does not exist in the database" << endl;
        result = false;
    }
    
    for (int i = 0; i < numBooks; i++)
    {
        title = books[i].getTitle();
        if (title.compare(bookTitle) == 0)
        {
            booktitleFound = 1;
            BookID = i;
            break;
        }
    }
    
    if (booktitleFound == 0)
    {
        cout << bookTitle << " does not exist in the database" << endl;
        result = false;
    }
    
    if (newRating < 0 || newRating > 5)
    {
        cout << newRating << " is not valid" << endl;
        result = false;
    }
    if (usernameFound == 1)
    {
        if(booktitleFound == 1)
        {
            if (newRating >= 0 && newRating <= 5)
            {
                // theUserNumRatings = users[UserID].getNumRatings();
                // theUserNumRatings++;
                // users[UserID].setNumRatings(theUserNumRatings);
                users[UserID].setRatingAt(BookID, newRating);
                result = true;
            }
    
        }
        
        //users[UserID].setRatingAt(BookID, newRating);
        // cout << books[numBooks].getRatingAt(BookID) << endl;
    }
    
    return result;
}

void Library::viewRatings(string name)
{
    string names;
    int UserID = 200;
    int usernameFound = 0;
    
    if (numBooks == 0 || numUsers == 0)
    {
        cout << "Database has not been fully initialized" << endl;
        cout << endl;
        return;
    }
    for (int i = 0; i <= numUsers; i++)
    {
        names = users[i].getUsername();
        if ( names.compare(name) == 0)
        {
            usernameFound = 1;
            UserID = i;
            // break;
        }
    }
    if (usernameFound == 0)
    {
        cout << name << " does not exist in the database" << endl;
        return;
    }
    if (usernameFound == 1)
    {
        if (users[UserID].getNumRatings() == 0)
        {
            cout << name << " has not rated any books yet" << endl;
            cout << endl;
            return;
        }
        else
        {
            cout << "Here are the books that " << name << " rated" << endl;
            for ( int i = 0; i < users[UserID].getNumRatings(); i++)
            {
                if (users[UserID].getRatingAt(i) >= 1 && users[UserID].getRatingAt(i) <= 5 )
                {
                    cout << "Title : " << books[i].getTitle() << endl;
                    cout << "Rating : " << users[UserID].getRatingAt(i) << endl;
                    cout << "-----" << endl;
                }
            }
            cout << endl;
        }
    }
    
    
}

void Library::getRecommendations (string name)
{
    string names;
    string title;
    string recommendationBooks[200][3];
    int ssd[200];
    int UserID = 200;
    int usernameFound = 0;
    int ratingOne;
    int ratingTwo;
    int diffValue;
    int smallestSSD;
    int theMostSimilarUserID;
    int numRecomm = 0;
    
    
    
    if (numBooks == 0 || numUsers == 0)
    {
        cout << "Database has not been fully initialized" << endl;
        cout << endl;
        return;
    }
    
    for (int i = 0; i < numUsers; i++)
    {
        names = users[i].getUsername();
        if ( names.compare(name) == 0)
        {
            usernameFound = 1;
            UserID = i;
            break;
        }
    }
    
    if (usernameFound == 0)
    {
        cout << name << " does not exist in the database" << endl;
        cout << endl;
        return;
    }
    
   for ( int i = 0; i < numUsers; i++ )
    {
        for ( int j = 0; j < users[i].getNumRatings(); j++ )
        {
            ratingOne = users[UserID].getRatingAt(j);
            ratingTwo = users[i].getRatingAt(j);
            diffValue = ratingOne - ratingTwo;
            ssd[i] = ssd[i] + pow (diffValue, 2);
        }
    }
    
    
    smallestSSD = 25 * 50;
    theMostSimilarUserID = 200;
    
    for (int i = 0; i < numUsers; i++)
    {
        if (smallestSSD > ssd[i] && i != UserID)
        {
            smallestSSD = ssd[i];
            theMostSimilarUserID = i;
            //cout << "the similar user : " << users[theMostSimilarUserID].getUsername() << " ( " << ssd[theMostSimilarUserID] << " )" <<endl;
        }
    }
    
    for (int i = 0; i < users[theMostSimilarUserID].getNumRatings(); i++)
    {
        if (users[UserID].getRatingAt(i) == 0 && users[theMostSimilarUserID].getRatingAt(i) >= 3)
        {
            recommendationBooks[numRecomm][0] = books[i].getTitle();
            recommendationBooks[numRecomm][1] = books[i].getAuthor();
            recommendationBooks[numRecomm][2] = i;
            numRecomm++;
        }
    }
    
    if (numRecomm == 0)
    {
        cout << "There are no recommendations for " << name << " at the present" << endl;
        cout << endl;
        return;
    }
    
    cout << "Here are the list of recommendations: " << endl;
    
    for (int i = 0; i < numRecomm; i++)
    {
        if (i < 5)
        {
            cout << recommendationBooks[i][0] << " by " << recommendationBooks[i][1] << endl;
        }
    }
    cout << endl;
    
}
