// Daniel Kim: CS1300 Fall 2018
// Recitation: 107 – Andrew Altomare
// Cloud9 Workspace Editor Link: https://ide.c9.io/kanieldim/csci1300
// Homework 2 - Problem 4

#include <iostream>
#include <math.h>

using namespace std;
    
/*
    Algorithm: Calculate the luminosity of an astronomical object by using brightness and distance from the observer
            1. Take the value of brightness and distance
            2. Use the formula L = 4 * brightness * 3.14159(pi) * (distance)^2 to figure out luminosity
            3. Return the result of the luminosity
    Input values: brightness, distance (double)
    Output: nothing
    Returns: luminosity (L) (integer)
*/

int luminosity(double brightness, double distance) //function
{
    int L; // Define one variable L to store the value of the luminosity
    L = 4 * brightness * 3.14159 * pow(distance,2); //formula in order to get luminosity, L
    return L; // return L
}

int main()
{
    double brightness, distance; // test case 1 for luminosity
    brightness = 1.5;
    distance = 17.8;
    cout << luminosity(brightness, distance) << endl;
    brightness = 5.2; // test case 2 for luminosity
    distance = 62.3;
    cout << luminosity(brightness, distance);
    return 0; //program ended with exit code 0
}