// Daniel Kim: CS1300 Fall 2018
// Recitation: 107 – Andrew Altomare
// Cloud9 Workspace Editor Link: https://ide.c9.io/kanieldim/csci1300
// Homework 2 - Problem 1

#include <iostream>

using namespace std;

/*
    Algorithm: Convert seconds to following format (x hours, y minutes, z seconds)
            1. Take one input of Seconds
            2. In order to get hours, divide the input by 3600
            3. In order to get minutes, subtract the input by 3600 seconds times the number of hours then divide by 60
            4. In order to get seconds, subtract the input by 3600 seconds times the number of hours and 60 seconds times the number of minutes
            5. Return the new format
    Input values : Seconds (integer)
    Output: hours, minutes, seconds (integer)
    Returns: nothing
        
    Conversions:
    hours = (Seconds / 3600); //in order to get hours
    minutes = ((Seconds - 3600 * x )/ 60); //in order to get minutes
    seconds = (Seconds - 3600 * x - 60 * y); //in order to get seconds
*/
   
void convertSeconds(int Seconds)
{
    int x, y, z; // define three variables to store hours(x), minutes(y), seconds(z)
    x = (Seconds / 3600); // in order to get hours
    y = ((Seconds - 3600 * x )/ 60); // in order to get minutes
    z = (Seconds - 3600 * x - 60 * y); // in order to get seconds
    cout << x << " hour(s) " << y << " minute(s) " << z << " second(s)" <<endl; // print the result
}

int main() 
{
    int Seconds = 3671;// test case 1 for convertSeconds
    convertSeconds(Seconds);
    Seconds = 10236; // test case 2 for convertSeconds
    convertSeconds(Seconds);
    return 0; // program ended with exit code 0
}