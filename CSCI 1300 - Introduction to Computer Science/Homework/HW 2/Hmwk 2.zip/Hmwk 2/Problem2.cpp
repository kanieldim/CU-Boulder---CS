// Daniel Kim: CS1300 Fall 2018
// Recitation: 107 – Andrew Altomare
// Cloud9 Workspace Editor Link: https://ide.c9.io/kanieldim/csci1300
// Homework 2 - Problem 2

#include <iostream>

using namespace std;

/*
    Algorithm: Convert Celsius to Fahrenheit
            1. Take the value celcius
            2. Conversion: fahrenheit = celcius * (9.0/5.0) +32
            3. Return into Fahrenheit
    Input values : celcius
    Output : fahrenheit
    Return : nothing
*/

void celsiusToFahrenheit(double celcius) // function of the conversion
{
    double fahrenheit = celcius * (9./5.) +32; //conversion
    cout << "The temperature of " << celcius << " in Celsius" << " is " << fahrenheit << endl; // print the result
}

int main () 
{
    double celcius = 38; // test case 1 for celsiusToFahrenheit
    celsiusToFahrenheit(celcius);
    celcius = 69; // test case 2 for celsiusToFahrenheit
    celsiusToFahrenheit(celcius);
    return 0; // program ended with exit code 0
}