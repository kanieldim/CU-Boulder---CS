// Daniel Kim: CS1300 Fall 2018
// Recitation: 107 – Andrew Altomare
// Cloud9 Workspace Editor Link: https://ide.c9.io/kanieldim/csci1300
// Homework 2 - Problem 3

#include <iostream>
#include <math.h>

using namespace std;

/*
    Algorithm: Calculate the U.S. population in exactly one year (365 days)
            1. Take the value of the initial population (integer)
            2. In order to get number of births, divide seconds in 1 year by 8
            3. In order to get number of death, divide seconds in 1 year by 12
            4. In order to get number of immigration, divide seconds in 1 year by 27
            5. To get the new population, add birth and immigration to initial population, and subtract death from initial population 
    Input values : initial population (integer)
    Output: nothing
    Returns: new population (integer)
*/

int population(int initial_population) //function
{
    int OneYearInSeconds; //  define one variable to store one year in seconds
    int birth, death, immigrant; // define three variables to store the three rates of change
    int new_population; // define a variable to store the new population after one year
    
    OneYearInSeconds = 365 * 24 * 60 * 60; //calculate one year in seconds
    birth = OneYearInSeconds / 8; // get the number of births in one year
    death = OneYearInSeconds / 12; // get the number of deaths in one year
    immigrant = OneYearInSeconds / 27; // get the number of immmigrats in one year
    new_population = initial_population + birth - death + immigrant; // new population after one year
    return new_population; // return new_population
}

int main()
{
    int initial_population = 1000000; // test case 1 for population
    cout << population(initial_population) << endl;
    initial_population = 254625; // test case 2 for population
    cout << population(initial_population);
    return 0; //program ended with exit code 0
}