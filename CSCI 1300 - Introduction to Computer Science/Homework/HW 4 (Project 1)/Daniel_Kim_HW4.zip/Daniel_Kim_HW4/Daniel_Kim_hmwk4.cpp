// CSCI1300 Fall 2018
// Author: <Daniel Kim>
// Recitation: <103> - <Andrew Altomare>
// Cloud9 Workspace Editor Link: <https://ide.c9.io/kanieldim/csci1300>
// Project1


///////////////////////////////////////////////////////////////////////////////////////////////////
// Step1: Steps to solve this problem
// write an algorithm in pseudocode explaining on how you are approaching the problem, step by step 
///////////////////////////////////////////////////////////////////////////////////////////////////

/*
    Algorithm: Make Jeopardy Dice game.
            1. Make functions for human player, computer player, turn total, and game
            2. For turn total, set a variable as diceNumber and then set up switch statement from the rules of dice
                    - For case 1, 6, make turn total 0, and make sure the player won't be able to roll a dice again
                    - For case 3, make turn total 15 no matter the previous total, and make sure the player won't be able to roll a dice again
                    - For case 2, 4, 5, add these numbers to turn total, and make sure the player will get to choose to roll again
                    - If the current turn is human, print "You rolled a <diceNumber>"
                    - If the current turn is computer, print "Computer rolled a <diceNumber>"
            3. For human player, set current turn as human and make cin to answer if you want to roll a dice
                    - If human player said yes, use turn total function
                    - If human player said no, give up turn to computer
            4. For computer player, set current turn as computer
                    - Make sure to automatically decide "yes" to roll a dice until the turn score is over 10
            5. For game function, set up human score and computer score to 0 and set winner decision to "No"
            7. Set while statement till winner is decided
            8. Set if statement if human score or computer score is larger than 100, change winner decision to "Yes" to end the game
    Input values : nothing
    Output : winner (human or computer)
    Return : nothing
*/




///////////////////////////////////////////////////////////////////////////////////////////////////
// Step2: Code it up! 
// After finishing up your pseudocode, translate them into c++ 
// IMPORTANT: rollDice() and main() are already written for you.
// You need to complete game function as well as at least 3 other additional functions
///////////////////////////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <cmath>
#include <cstdlib>
#include <unistd.h>
#include <stdio.h>
using namespace std; 

/*
rollDice 
returns a random integer between 1 and 6, works as rolling a dice.
return value, int number (1-6)
*/

int rollDice()
{
	return random() % 6 + 1; 
}

string rollContinue; // to be able to answer in letters
string turn; // to set current turn as "human" or "computer"
int turnTotal; // to set turn total for each turn

void turnTotalF (void) // setting up the rules (dice numbers) through a function
{
    int diceNumber;
    
    diceNumber = rollDice(); // use rollDice() function and set it equal to diceNumber
    
    switch(diceNumber) // set up switch cases
    {
        case 1: // for case 1, 6, set turnTotal as 0 and no re-rolls
        case 6:
        {
            turnTotal = 0;
            rollContinue = "N";
            break;
        }
        case 3: // for case 3, set turnTotal as 15 (no matter the previous result) and no re-rolls
        {
            turnTotal = 15;
            rollContinue = "N";
            break;
        }
        case 2: // for case 2, 4, 5, add these numbers to turnTotal and choose to re-roll
        case 4:
        case 5:
        {
            turnTotal = turnTotal + diceNumber;
            rollContinue = "Y";
            break;  
        }
        default:
        {
            rollContinue = "Y";
            break;
        }
    }
    if (turn == "human") // if current turn is human, print the following
    {
        cout << "You rolled a " << diceNumber << endl;
    }
    else // else current turn is computer, print the following
    {
        cout << "Computer rolled a " << diceNumber << endl; 
    }
}


int humanPlayer (int playerTotal) // fucntion for humanPlayer
{
    turnTotal = 0; // set turnTotal to 0
    turn = "human"; // set current turn as human
    
    cout << "Do you want to roll a dice (Y/N)?:" << endl;
    cin >> rollContinue;
    
    while (rollContinue == "y" || rollContinue == "Y") // while loop statement
    {
        turnTotalF(); // use turnTotalF function
         
        cout << "Your turn total is " << turnTotal << endl; // print turn total
         
        if (rollContinue == "n" || rollContinue == "N") // if answer is n, break
        {
             break;
        }
        
        cout << "Do you want to roll again (Y/N)?:" << endl;
        cin >> rollContinue;
        
     }
     
     playerTotal = playerTotal + turnTotal; // add turnTotal to overall score
     
     return playerTotal; // return playerTotal
}

int computerPlayer (int playerTotal) // function for computerPlayer
{
    turnTotal = 0; // set turnTotal to 0
    
    rollContinue = "Y"; // automatic "Y"
    turn = "computer"; // set current turn as computer
    
    while (turnTotal < 10 && rollContinue == "Y") // while turnTotal is less than 10 and rollContinue is "Y"
    {
        turnTotalF(); // use turnTotalF fucntion
        cout << "Computer turn total is " << turnTotal << endl; // print the result
    }
    
    playerTotal = playerTotal + turnTotal; // add turntotal to playerTotal
    
    return playerTotal; // return playerTotal
}

void introMessage(string wording) // void fucntion for introduction
{
    cout << wording << endl << endl;
}


/*
game 
driver function to play the game
the function does not return any value
*/

void game() // fucntion for jeopardy dice score
{
    int humanScore = 0;
    int computerScore = 0;
    string winner = "N"; // set winner as "N" 
    
    introMessage("Welcome to Jeopardy Dice!"); // recall intro() fucntion;
    
    while (winner == "N") // while statement as winner has not decided
    {
        cout << "It is now human's turn" << endl << endl;
        
        humanScore = humanPlayer(humanScore); // use humanPlayer function
        cout << "computer: " << computerScore << endl; // result
        cout << "human: " << humanScore << endl << endl; // result
        
        if (humanScore >= 100) // if humanScore is larger than 100
        {
            cout << "Congratulations! human won this round of jeopardy dice!" << endl; // print the following
            winner = "Y"; // set as winner is decided
            break; // break
        }
        
        cout << "It is now computer's turn" << endl << endl;
        
        computerScore = computerPlayer(computerScore); // use computerPlayer function
        cout << "computer: " << computerScore << endl; // result
        cout << "human: " << humanScore << endl << endl; // result
        
        if (computerScore >= 100) // if computerScore is larger than 100
        {
            cout << "Congratulations! computer won this round of jeopardy dice!" << endl; // print the following
            winner = "Y"; // set as winner is decided
            break; // break
        }
    }
}


// ///////////////////////////////////////////////////////////////////////////////////////////////////
// // don't change the main. 
// // Once you finished please paste your code above this line 
// ///////////////////////////////////////////////////////////////////////////////////////////////////


int main()
{
	// start the game! 
	game();
	return 0;
}