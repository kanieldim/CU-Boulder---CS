// Daniel Kim: CS1300 Fall 2018
// Recitation: 107 – Andrew Altomare
// Cloud9 Workspace Editor Link: https://ide.c9.io/kanieldim/csci1300
// Homework 3 - Problem 2

#include <iostream>

using namespace std;

/*
    Algorithm: Count how many digits the number has
            1. Take the value of integer
            2. Set digits as 0
            3. If integer is not between -999 and 999, return to 1
            4. If integer is negative, multiply by -1
            5. If integer is greater than or equal to 0, add 1 to digits (total 1 digit)
            6. If integer is more than or equal to 10, add 1 more to digits (total 2 digits)
            7. If integer is more than or equal to 100, add 1 more to digits (total3 digits)
    Input values : integer (number)
    Output : nothing
    Return : integer (digits)
*/

int countDigits(int number) //fucntion
{
    int digits = 0; // set input value digits
    
    if(number >= 1000 || number <= -1000) // if number is not between -999 and 999, return to 1
    {
        return 1;
    }
    
    cout << number << " has " ; // print "number has"
    
    if (number < 0) // if number is negative, multiply number by -1
    {
        number = number * -1; // equation
    }
    
    if (number >= 0) // if number is more than or equal to 0, add 1 to digits (total 1 digits)
    {
        digits = digits + 1; // add 1 to digits (total 1 digits)
    }
    
    if (number >= 10) // if number is more than or equal to 10, add 1 more to digits (total 2 digits)
    {
        digits = digits + 1; // add 1 more to digits (total 2 digits)
    }
    
    if (number >= 100) // if number is more than or equal to 100, add 1 more to digits (total 3 digits)
    {
         digits = digits + 1; // add 1 more to digits (total 3 digits)
    }
    
    return digits; //return digits
}
    
int main()
{
    cout << countDigits(560) << " digits" << endl; // test case 1
    cout << countDigits(-55) << " digits" << endl; // test case 2
    cout << countDigits(8) << " digits" << endl; // test case 3
    
    return 0;
}
