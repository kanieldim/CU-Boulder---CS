// Daniel Kim: CS1300 Fall 2018
// Recitation: 107 – Andrew Altomare
// Cloud9 Workspace Editor Link: https://ide.c9.io/kanieldim/csci1300
// Homework 3 - Problem 1

#include <iostream>

using namespace std;

/*
    Algorithm: Provide the Collatz sequence based on the value of the input
            1. Take the value of integer
            2. If integer is even, the next value should be n/2
            3. If integer is odd, the next value should be 3n+1
            4. If integer is negative and does not apply from above , return to 0
    Input values : integer (n)
    Output : nothing
    Return : integer (n)
*/

int collatzStep(int n) // function
{
    
    if ( n % 2 == 0 && n >= 0 ) // if n is even and if n is positive
    {
        n = n / 2; // equation
    }
    else if (n % 2 == 1) // if n is odd
    {
        n = 3 * n + 1; // equation
    }
    else // if n doesn't apply at all from above
    {
        return 0; // return 0
    }
    
    return n; // return n
}

int main()
{
    cout << collatzStep(4) << endl; // test case 1
    cout << collatzStep(7) << endl; // test case 2
    cout << collatzStep(-5) << endl; // test case 3
    cout << collatzStep(-4) << endl; // test case 4
    
    return 0;
}