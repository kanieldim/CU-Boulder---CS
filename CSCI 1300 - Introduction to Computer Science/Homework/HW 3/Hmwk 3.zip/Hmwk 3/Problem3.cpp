// Daniel Kim: CS1300 Fall 2018
// Recitation: 107 – Andrew Altomare
// Cloud9 Workspace Editor Link: https://ide.c9.io/kanieldim/csci1300
// Homework 3 - Problem 3

#include <iostream>

using namespace std;

/*
    Algorithm: Calculate the number of days in a particular month
            1. Input integer as month
            2. Set switch statement
            3. For case 1, 3, 5, 7, 8, 10, 12, calculate as 31 days
            4. For case 4, 6, 9, 11, calculate as 30 days
            5. For case 2, calculate as 28 or 29 days
            6. If month number is not between 1 and 12, set as invald month number
    Input values : integer (month)
    Output : number of days in the month
    Return : nothing
*/

void daysOfMonth(int month) // function
{
    switch(month) // set switch statment
    {
        case 1 : // code to be executed if month = 1
        case 3 : // code to be executed if month = 3
        case 5 : // code to be executed if month = 5
        case 7 : // code to be executed if month = 7
        case 8 : // code to be executed if month = 8
        case 10 : // code to be executed if month = 10
        case 12 : // code to be executed if month = 12
            cout << "Month " << month << " has 31 days" << endl;
            break; // for month 1, 3, 5, 7, 8, 10, 12, set 31 days and break
        
        case 4 : // code to be executed if month = 4
        case 6 : // code to be executed if month = 6
        case 9 : // code to be executed if month = 9
        case 11 : // code to be executed if month = 11
            cout << "Month " << month << " has 30 days" << endl;
            break; // for month 4, 6, 9, 11, set 30 days and break
            
        case 2 : // code to be executed if month = 2
            cout << "Month " << month << " has 28 or 29 days" << endl;
            break; // for month 2, set 28 or 29 days and break
            
        default : // code to be executed if month doesn't match any cases
            cout << "Invalid month number" << endl;
    }
}

int main() 
{
    daysOfMonth(5); // test case 1
    daysOfMonth(10); // test case 2
    daysOfMonth(6); // test case 3
    daysOfMonth(14); // test case 4
    
    return 0;
}