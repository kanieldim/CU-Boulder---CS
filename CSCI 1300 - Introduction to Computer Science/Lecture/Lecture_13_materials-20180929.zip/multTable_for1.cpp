#include <iostream>
using namespace std;

int main()
{
    // write a multiplication table for 5
    /* Output:
    5 10 15 20 25 30 35 ... 50
    */
    
    // Option 1: addition/accumulation
    // int i = 5;
    // int total = 0;
    // while(total < 50)
    // {
    //     total  = total + 5;
    //     cout << total << " ";
    // }
    
    // Option 2: multiplication
    // int i = 5;
    // int j = 0; /// 1, 2, ... 10
    // while(j < 10)
    // {
    //     j++;
    //     cout << i * j << " ";
    // } 
    
    // multiplication table for 1 through 8
    int i = 1;
    for (i = 1; i <=8; i++)
    {
        int j = 0; /// 1, 2, ... 10
        while(j < 10)
        {
            j++;
            cout << i * j << " ";
        }
        cout << endl;
        //i++;
    }
    
    
    return 0;
}
