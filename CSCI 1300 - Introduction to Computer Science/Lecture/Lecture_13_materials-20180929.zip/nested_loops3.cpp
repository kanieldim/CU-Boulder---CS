/*
Prints asterisks in even columns, dashes in odd columns
-*-*- 
-*-*- 
-*-*-
*/

#include <iostream>
using namespace std;

int main()
{
    int i,j;
    for (i=0  ; i < 3 ; i++ )
    {
        for ( j=0  ; j<5  ; j++  )
        {
            // if j is even print *, if j is odd print _
            if (j%2 == 1)  // if j is odd, then the column number is even
            {
                cout << "*";
            }
            else
            {
                cout << "_";
            }
        }
        cout << "\n";
    }
    
    return 0;
}