#include <iostream> //all programs that perform input and output need the iostream 

//namespaces are used to avoid naming conflicts. Always add it after the #include statements
using namespace std; 

/* main is a function (a collection of statements). Every C++ program must have a main()
 - it must have (), but there is nothing inside the parentheses
 - the statements go inside the curly braces { }
 */
 
int main()
{
    //what is endl and what does it do? How does the output differs if we do/don't add endl;
    cout << "Hello, world!";
    cout << "Hello, world!" << endl;  
    cout << "Hello, world!";
    cout << "Hello," << "world!" << endl;
    cout << "Hello," << " world!"<< endl;
    out << "Hello, " << "world! \n";
    
    // errors
    //cot << "Hello, world!" << endl; // syntax error at compile time
    //cout << "Hello, world! << endl;  // where is the end of the string. Plus, other error messages
    //cout << "Hollo, world!" << endl;   // compiles and runs fine, but output will be wrong 
    
    //returning the value 0 indicates the program finished succesfully (terminated)
    return 0;
    
}