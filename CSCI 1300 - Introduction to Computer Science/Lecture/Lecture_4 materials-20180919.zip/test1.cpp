#include <iostream> 

using namespace std;

int main()
{
    cout << "   X                            " << endl;
    cout << "  XXX" << endl;
    cout << " XXXXX" << endl;
    cout << "XXXXXXX" << endl;
    
    return 0;
}