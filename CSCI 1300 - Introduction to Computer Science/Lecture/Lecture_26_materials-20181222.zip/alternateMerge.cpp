#include <iostream>
#include<vector>
using namespace std;

/*
Given two vectors, merge the 2 by alternating the elements from both vectors.
If one vector is shorter tan the other, then alternate as long as you can and then apend the remaining elemnts from the longer vector.
E.g. 
v1 : {1, 4, 9, 16}
v2 : {10, 14, 19, 15, 8, 5}

then output will be: v3: [1, 10, 4, 14, 9, 19, 16, 15, 8, 5]
*/

vector<int> read_inputs()
{
   vector<int> result;
   int input;
   cout << "Please enter values, Q to quit: ";
   while (cin >> input)
   {
        result.push_back(input);
        cout << "Please enter values, Q to quit: ";
   }
    cin.clear(); 
    cin.ignore();
   return result;
}

void print(vector<int> values)
{
   for (int i = 0; i < values.size(); i++)
   {
      cout << values[i] << " ";
   }
   cout << endl;
}

vector<int> merge(vector<int> v1, vector<int> v2) {
    vector<int> v3;
    int i = 0;	// To keep track of the index in v1.
    int j = 0;	// To keep track of the index in v2.
    
    // This loop should run till either of the indexes are less than its vector's size.
    while (i < v1.size() && j < v2.size()) {
        v3.push_back(v1[i]);
        v3.push_back(v2[j]);
        i++;
        j++;
    }
    
    //If v1 is longer than v2, then insert all remaining values of v1 in v3..
    while (i < v1.size()) {
        v3.push_back(v1[i]);
        i++;
    }

    //If v2 is longer than v1, then insert all remaining values of v2 in v3.
    while (j < v2.size()) {
        v3.push_back(v2[j]);
        j++;
    }
    return v3;
}


vector<int> inPlaceMerge(vector<int> v1, vector<int> v2) {
    int i = 1;	// To keep track of index in v1 where the value from v2 should be inserted.
    int j = 0;	// To keep track of the index in v2.
    
    while (i < v1.size() && j < v2.size()) {
        v1.insert(v1.begin() + i, v2[j]);
        i = i + 2;	// because values of v2 should be inserted at indexes 1, 3, 5, 7 etc.
        j++;
    }
    
    //If v2 is longer than v1, then insert all remaining values of v2 in v1.
    while (j < v2.size()) {		
        v1.push_back(v2[j]);
        j++;
    }
    return v1;
}


main() {
    vector<int> one = read_inputs();
    vector<int> two = read_inputs();
    vector<int> three = merge(one, two);
    cout << "v1: ";
    print(one);
    cout << "v2: ";
    print(two);
    cout << "v3: ";
    print(three);
    
}