#include <iostream>
#include<vector>
using namespace std;

/*
Reference: https://leetcode.com/explore/interview/card/top-interview-questions-easy/92/array/567/
Given an array nums, write a function to move all 0's to the end of it while maintaining the relative order of the non-zero elements.
For example, given nums = [0, 1, 0, 3, 12], after calling your function, nums should be [1, 3, 12, 0, 0].
*/

vector<int> read_inputs()
{
   vector<int> result;
   int input;
   cout << "Please enter values, Q to quit: ";
   while (cin >> input)
   {
        result.push_back(input);
        cout << "Please enter values, Q to quit: ";
   }
    cin.clear(); 
    cin.ignore();
   return result;
}

void print(vector<int> values)
{
   for (int i = 0; i < values.size(); i++)
   {
      cout << values[i] << " ";
   }
   cout << endl;
}

vector<int> moveZeroes(vector<int> nums) {
    int i = 0;					//Index variable to iterate through the vector.
    int size = nums.size();		//To keep track zeros that have been moved back.
    
    while (i < size) {
    	/*Check if the value at index i is zero.
			If yes, then insert a zero at the end of the vector and remove/delete it from the current position.
		*/
        if (nums[i] == 0) {
            nums.push_back(0);
            nums.erase(nums.begin() + i);
            i--;			//Because when we delete the ith value(which had 0), then i is already at nexxt position(the one after 0 value)
            size--;			//As we are doing i--, we will be stuck in an infinite loop ones we hit the stream of 0 that we pushed at the end of the vector.
        }
    }
    return nums;
}


main() {
    vector<int> one = read_inputs();
    vector<int> three = moveZeroes(one);
    cout << "old: ";
    print(one);
    cout << "new: ";
    print(three);
    
}