#include <iostream>
#include <vector>
using namespace std;

/*
Insertion sort on given vector
*/

vector<int> read_inputs()
{
   vector<int> result;
   int input;
   cout << "Please enter values, Q to quit: ";
   while (cin >> input)
   {
        result.push_back(input);
        cout << "Please enter values, Q to quit: ";
   }
    cin.clear(); 
    cin.ignore();
   return result;
}

void print(vector<int> values)
{
   for (int i = 0; i < values.size(); i++)
   {
      cout << values[i] << " ";
   }
   cout << endl;
}

vector<int> insertionSort(vector<int> vec) {
    //loop that keeps track of the index of the element which is being placed at its right index.
    for (int i = 1; i < vec.size(); i++) {
        int j = i -1;
        bool flag = false;
        
        //Find the right index position for the element at i. 
        while (j >= 0 && vec[i] < vec[j]) {
            j --;
            flag = true;
        }

        if (flag) {
            vec.insert(vec.begin() + j + 1, vec[i]);
            vec.erase(vec.begin() + i + 1);    
        }
    }
    return vec;
}


main() {
    vector<int> one = read_inputs();
    vector<int> three = insertionSort(one);
    cout << "old: ";
    print(one);
    cout << "new: ";
    print(three);
    
}