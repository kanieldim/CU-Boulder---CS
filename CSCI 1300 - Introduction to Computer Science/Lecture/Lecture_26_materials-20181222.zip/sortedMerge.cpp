#include <iostream>
#include <vector>
using namespace std;

/*
Given two sorted vectors, merge the 2 vectors in such a way that the new vector is sorted too.
E.g. 
v1 : {1, 4, 9, 16}
v2 : {5, 14, 17, 19, 21, 23, 27]

then output will be: v3: [1, 4, 5, 9, 14, 16, 17, 19, 21, 23, 27]
*/

vector<int> read_inputs()
{
   vector<int> result;
   int input;
   cout << "Please enter values, Q to quit:";
   while (cin >> input)
   {
        result.push_back(input);
        cout << "Please enter values, Q to quit:";
   }
    cin.clear(); 
    cin.ignore();
    return result;
}

void print(vector<int> values)
{
   for (int i = 0; i < values.size(); i++)
   {
      cout << values[i] << " ";
   }
   cout << endl;
}

vector<int> sortedMerge(vector<int> v1, vector<int> v2) {
    vector<int> v3;
    int i = 0;	// To keep track of the index in v1.
    int j = 0;	// To keep track of the index in v2.
    
    // This loop should run till either of the indexes are less than its vector's size.
    while (i < v1.size() && j < v2.size()) {
        //Insert the item which is smaller out of the two vectors.
        if (v1[i] < v2[j]) {
            v3.push_back(v1[i]);
            i++;
        } else {
            v3.push_back(v2[j]);
            j++;
        }
    }
    
    //If v1 is longer than v2, then insert all remaining values of v1 in v3..
    while (i < v1.size()) {
        v3.push_back(v1[i]);
        i++;
    }

    //If v2 is longer than v1, then insert all remaining values of v2 in v1.
    while (j < v2.size()) {
        v3.push_back(v2[j]);
        j++;
    }
    return v3;
}


main() {
    vector<int> one = read_inputs();
    vector<int> two = read_inputs();
    vector<int> three = sortedMerge(one, two);
    cout << "v1: ";
    print(one);
    cout << "v2: ";
    print(two);
    cout << "v3: ";
    print(three);
    
}