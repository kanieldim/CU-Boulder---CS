#include <iostream>
#include "Question.h"
#include "choicequestion.h"

int main()
{
   string response;
   cout << boolalpha;

   // Make a quiz with two questions
   Question q1;
   q1.set_text("Who was the inventor of C++?");
   q1.set_answer("Bjarne Stroustrup");

   ChoiceQuestion cq1;
   cq1.set_text("In which country was the inventor of C++ born?");
   cq1.add_choice("Australia", false);
   cq1.add_choice("Denmark", true);
   cq1.add_choice("Korea", false);
   cq1.add_choice("United States", false);

   // Check answers for all questions
   q1.display();
   cout << "Your answer: ";
   getline(cin, response);
   cout << q1.check_answer(response) << endl;

   cq1.display();
   cout << "Your answer: ";
   getline(cin, response);
   cout << cq1.check_answer(response) << endl;

   return 0;
}

