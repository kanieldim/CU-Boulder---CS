#ifndef QUESTION_H
#define QUESTION_H

#include <string>

using namespace std;
class Question
{
public:
   Question();
   void set_text(string question_text);
   void set_answer(string correct_response);
   bool check_answer(string response) const;
   void display() const;
private:
   string text;
   string answer;
};

#endif