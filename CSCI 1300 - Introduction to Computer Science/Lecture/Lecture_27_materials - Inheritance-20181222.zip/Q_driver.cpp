#include <iostream>
#include <sstream>
#include <string>
#include "Question.h"
using namespace std;

// class Question
// {
// public:
//    Question();
//    void set_text(string question_text);
//    void set_answer(string correct_response);
//    bool check_answer(string response) const;
//    void display() const;
// private:
//    string text;
//    string answer;
// };
// Question::Question()
// { 
//    text = "";
//    answer = "";
// }
// void Question::set_text(string question_text)
// {
//    text = question_text;
// }
// void Question::set_answer(string correct_response)
// {
//    answer = correct_response;
// }
// bool Question::check_answer(string response) const
// {
//    return response == answer;
// }
// void Question::display() const
// {
//    cout << text << endl;
// }

int main()
{
   string response;

   // Show Boolean values as true, false
   cout << boolalpha; // Notice this manipulator

   Question q1;
   q1.set_text("Who was the inventor of C++?");
   q1.set_answer("Bjarne Stroustrup");

   q1.display();
   cout << "Your answer: \n";
   getline(cin, response);
   cout << q1.check_answer(response) << endl;

   return 0;
}
