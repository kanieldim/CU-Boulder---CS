#include <iostream>
#include <string>
using namespace std;

// how many As are in a given string?
int countAs(string x);
int main()
{
    string str = "ABC";
    cout << countAs(str) << endl;
    
    return 0;
}

int countAs(string x)
{
    if (x.length() == 0) 
    {
        return -1;
    }
    int count = 0;
    
    for(int i=0; i < x.length();i++)
    {
        if (x[i] == 'A')
        {
            count++;
        }
    }
    return count;
}