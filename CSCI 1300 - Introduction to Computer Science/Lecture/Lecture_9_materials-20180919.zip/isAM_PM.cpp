#include <iostream>
using namespace std;

// AM or PM?
void isAM_PM(int myHour);

int main() 
{
    int hour;
    cout << "Please enter the current hour:";
    cin >> hour;
    
    isAM_PM(hour);  // function call
    
    return 0;
}

void isAM_PM(int myHour)
{
    
}













// void wishGreetings(int hourOfDay) 
// {
//     if (hourOfDay < 12) 
//     {
//         cout << "Good Morning";
//     } 
//     else if  (hourOfDay < 17) 
//     {
//         cout << "Good Afternoon";
//     } 
//     else 
//     {
//         cout << "Good Evening";
//     }
// }