#include <iostream>
using namespace std;

int main() 
{
    bool x;
    int a, b, c;
    
    a = 0;
    b = 5;
    c = 7;
    
    x = 6 <= b <= 7; // doesn't work
    char answer = 'n';
    
    if ((answer == 'Y') || (answer == 'y'));
    
    cout << x << endl;
   
}