#include <iostream>
#include <string>
using namespace std;

int main()
{
    string s1 = "hello";
    int i = 0;
    int count  = 0;
    while (s1[i] != '\0')
    {
        if (s1[i] == 'l')
        {
            count ++;
        }
        cout << s1[i] << endl;
        i++;
    }
    // for loop equivalent
    for (i=0; i < s1.length(); i++)
    {
        cout << s1[i];
    }
    cout << "\n the number of occurences of the letter 'l' is: " << count << endl;
    return 0;
}