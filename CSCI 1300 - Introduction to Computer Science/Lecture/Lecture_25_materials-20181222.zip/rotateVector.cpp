#include <iostream>
#include<vector>
using namespace std;

/*
Rotate an array of n elements to the right by k steps.
For example, with n = 7 and k = 3, the array [1,2,3,4,5,6,7] is rotated to [5,6,7,1,2,3,4].
*/

vector<int> read_inputs()
{
   vector<int> result;
   int input;
   cout << "Please enter values, Q to quit: ";
   while (cin >> input)
   {
        result.push_back(input);
        cout << "Please enter values, Q to quit: ";
   }
    cin.clear(); 
    cin.ignore();
   return result;
}

void print(vector<int> values)
{
   for (int i = 0; i < values.size(); i++)
   {
      cout << values[i] << " ";
   }
   cout << endl;
}

vector<int> rotate(vector<int> nums, int k) {
    for (int i = 0; i < k; i++) {
        nums.insert(nums.begin(), nums[nums.size()-1]);
        nums.pop_back();
    }
    return nums;
}


main() {
    vector<int> one = read_inputs();
    vector<int> three = rotate(one, 3);
    cout << "old: ";
    print(one);
    cout << "new: ";
    print(three);
    
}