#include <iostream>
#include<vector>
using namespace std;

/*
Given an array nums, write a function to move all 0's to the end of it while maintaining the relative order of the non-zero elements.

For example, given nums = [0, 1, 0, 3, 12], after calling your function, nums should be [1, 3, 12, 0, 0].
*/

vector<int> read_inputs()
{
   vector<int> result;
   int input;
   cout << "Please enter values, Q to quit: ";
   while (cin >> input)
   {
        result.push_back(input);
        cout << "Please enter values, Q to quit: ";
   }
    cin.clear(); 
    cin.ignore();
   return result;
}

void print(vector<int> values)
{
   for (int i = 0; i < values.size(); i++)
   {
      cout << values[i] << " ";
   }
   cout << endl;
}

vector<int> moveZeroes(vector<int> nums) {
    int i=0;
    int size = nums.size();
    while ( i< size) {
        if (nums[i] == 0) {
            nums.push_back(0);
            nums.erase(nums.begin()+i);
            size--;
        } else {
            i++;
        }
    }
    return nums;
}


main() {
    vector<int> one = read_inputs();
    vector<int> three = moveZeroes(one);
    cout << "old: ";
    print(one);
    cout << "new: ";
    print(three);
    
}