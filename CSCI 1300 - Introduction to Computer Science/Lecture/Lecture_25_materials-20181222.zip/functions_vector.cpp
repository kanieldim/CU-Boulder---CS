#include <iostream>
#include <vector>

using namespace std;


vector<double> read_inputs();
vector<double> multiply(vector<double> values, double factor);
void print(vector<double> values);

int main()
{  
   vector<double> values = read_inputs();
   print(values);
   vector<double> doubleValues = multiply(values, 2);
   print(doubleValues);

   return 0;
}
/**
   Reads a sequence of floating-point numbers.
   @return a vector containing the numbers
 */
vector<double> read_inputs()
{
   vector<double> result;
   cout << "Please enter values, Q to quit:" << endl;
   bool more = true;
   while (more)
   {  
      double input;
      cin >> input;
      if (cin.fail())
      {
         more = false;
      }
      else 
      {
         result.push_back(input);
      }
   }
   return result;
}

/**
   Multiplies all elements of a vector by a factor
   @param values a vector
   @param factor the value with which each element is multiplied
 */
vector<double> multiply(vector<double> values, double factor)
{
   for (int i = 0; i < values.size(); i++)
   {
      values[i] = values[i] * factor;
   }
   return values;
}

/**
   Prints the elements of a vector, separated by commas.
   @param values a vector
 */
void print(vector<double> values)
{
   for (int i = 0; i < values.size(); i++)
   {
      if (i > 0) { cout << ", "; }
      cout << values[i];
   }
   cout << endl;
}

/**
   Multiplies all elements of a vector by a factor
   @param values a vector
   @param factor the value with which each element is multiplied
 */
void multiply2(vector<double>& values, double factor)
{
   for (int i = 0; i < values.size(); i++)
   {
      values[i] = values[i] * factor;
   }
}