#include <iostream>
using namespace std;

int main()
{
    int numberOfLanguages;
    cout << "Hello reader.\n"
    << "Welcome to C++. \n";

    cout << "How many foreign languages do you speak?";
    cin >> numberOfLanguages;

    cout << "That's great! You can speak " << numberOfLanguages ;
    cout << " languages" << endl;

    return 0;
}
