#include <iostream>
using namespace std;

int main()
{
    string dogName;
    cout << "Hello reader.\n"
    << "Welcome to C++. \n";

    cout << "What is the name of your dog? ";
    cin >> dogName;

    cout << "That's great! Hello " << dogName << endl ;

    return 0;
}