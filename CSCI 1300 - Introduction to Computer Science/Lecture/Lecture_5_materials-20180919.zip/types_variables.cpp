#include <iostream>
#include <math.h>
using namespace std;

int main()
{
    int a,b;
    double c;

    a = 17;
    b = 5;
    c = (double) (a/b);

    // "Highest-order operand" determines type of arithmetic "precision" performed

    cout << "17/5 = " << a/b << "\n" ;
    cout << "17.0/5 = " << (double)a/b << endl;
    cout << "17/5.0 = " << a / (double)b << endl;
    cout << "17/5 = " << (double) (a/b) << endl;
    cout << "c = " << c << endl;
    cout << "c/2 = " << c/2 << endl;
    cout << "(a/b) / 2 = " << (double)(a/b) /2 << endl;
    cout << "a/b/2 = " << a/b/2 << endl;

    cout << "1/2/3.0/4 = " << 1/2/3.0/4 << endl;
    return 0;
}
