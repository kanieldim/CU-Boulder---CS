/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_468(unsigned *p)
{
    *p = 3348125700U;
}

unsigned getval_401()
{
    return 3267856712U;
}

void setval_393(unsigned *p)
{
    *p = 2496104776U;
}

void setval_481(unsigned *p)
{
    *p = 3347663081U;
}

void setval_316(unsigned *p)
{
    *p = 1491420577U;
}

unsigned addval_290(unsigned x)
{
    return x + 3281031248U;
}

void setval_148(unsigned *p)
{
    *p = 2425393240U;
}

unsigned getval_143()
{
    return 3284633928U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_173(unsigned *p)
{
    *p = 3381969289U;
}

void setval_496(unsigned *p)
{
    *p = 3281043849U;
}

unsigned addval_349(unsigned x)
{
    return x + 3281049289U;
}

void setval_487(unsigned *p)
{
    *p = 2425473673U;
}

void setval_376(unsigned *p)
{
    *p = 3374896777U;
}

void setval_141(unsigned *p)
{
    *p = 3676883593U;
}

unsigned addval_404(unsigned x)
{
    return x + 2430634328U;
}

unsigned getval_142()
{
    return 3677932169U;
}

unsigned getval_251()
{
    return 3286272328U;
}

unsigned addval_321(unsigned x)
{
    return x + 2425405897U;
}

unsigned addval_464(unsigned x)
{
    return x + 3380920585U;
}

unsigned addval_268(unsigned x)
{
    return x + 3372796553U;
}

void setval_269(unsigned *p)
{
    *p = 2429979020U;
}

unsigned addval_328(unsigned x)
{
    return x + 3385117321U;
}

void setval_388(unsigned *p)
{
    *p = 2497743176U;
}

void setval_450(unsigned *p)
{
    *p = 3677929881U;
}

unsigned addval_490(unsigned x)
{
    return x + 3531134601U;
}

unsigned addval_408(unsigned x)
{
    return x + 3674786505U;
}

unsigned getval_238()
{
    return 3380926089U;
}

unsigned getval_133()
{
    return 3676356993U;
}

unsigned getval_310()
{
    return 3676362381U;
}

unsigned addval_225(unsigned x)
{
    return x + 3525886345U;
}

void setval_327(unsigned *p)
{
    *p = 3224423049U;
}

unsigned addval_197(unsigned x)
{
    return x + 3677935243U;
}

unsigned getval_347()
{
    return 3767093447U;
}

unsigned getval_113()
{
    return 3285616869U;
}

unsigned getval_358()
{
    return 2464188744U;
}

unsigned getval_433()
{
    return 2430634248U;
}

void setval_444(unsigned *p)
{
    *p = 2447411528U;
}

unsigned getval_303()
{
    return 3223372169U;
}

void setval_246(unsigned *p)
{
    *p = 3677932171U;
}

unsigned getval_343()
{
    return 3252717896U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
